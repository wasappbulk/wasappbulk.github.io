/**
 * SUPABASE CONFIGURATION
 *
 * IMPORTANT: Create a config.js from this template
 * NEVER commit config.js to git - it contains secrets!
 *
 * Steps:
 * 1. Copy this file: cp config.example.js config.js
 * 2. Add config.js to .gitignore
 * 3. Fill in your actual values from Supabase Dashboard
 */

const SUPABASE_CONFIG = {
  // Get from: Supabase Dashboard → Settings → API
  URL: 'https://isfaiawbywrtwvinkizb.supabase.co',

  // Get from: Supabase Dashboard → Settings → API → Anon public
  ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlzZmFpYXdieXdydHd2aW5raXpiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzEyMzIyMTQsImV4cCI6MjA4NjgwODIxNH0.DkuRC5vRmuXlds-z1TvTHj2pQsoFSsqPEINOlnaN2n0',
};

// Export for popup.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = SUPABASE_CONFIG;
}
