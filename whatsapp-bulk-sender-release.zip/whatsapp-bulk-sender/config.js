const SUPABASE_CONFIG = {
  URL: 'https://isfaiawbywrtwvinkizb.supabase.co',
  ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlzZmFpYXdieXdydHd2aW5raXpiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzEyMzIyMTQsImV4cCI6MjA4NjgwODIxNH0.DkuRC5vRmuXlds-z1TvTHj2pQsoFSsqPEINOlnaN2n0',
};
